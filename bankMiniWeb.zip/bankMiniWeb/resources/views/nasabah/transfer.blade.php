@extends('layouts.nasabah')

@section('title', 'Transfer - Bank Mini')
@section('header_title', 'Transfer Rekening')
@section('header_subtitle', 'Kirim uang dengan mudah dan aman ke sesama rekening Bank Mini.')

@section('content')
<div class="pb-10">
    <!-- MOBILE HEADER INFO -->
    <div class="lg:hidden pt-4 pb-2">
        <h2 class="text-xl font-bold text-textDark">Transfer Rekening</h2>
        <p class="text-textGray text-[10px]">Kirim uang dengan mudah dan aman.</p>
    </div>

    <!-- MAIN VIEW (Form & Recent History) -->
    <div id="viewMain" class="fade-in {{ request()->has('page') ? 'hidden' : 'block' }}">
    <div id="transferMainView">
        <!-- TOP SECTION: Saldo Cards -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-4 lg:mt-0">
            <!-- Card Kiri: Saldo Diterima -->
            <div class="bg-primary-gradient rounded-2xl p-6 lg:p-7 relative overflow-hidden shadow-lg text-white">
                <div class="absolute right-6 top-1/2 -translate-y-1/2 w-32 h-32 opacity-[0.06] text-white">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" class="w-full h-full">
                        <path d="M21 12V7H5a2 2 0 010-4h14v4"></path>
                        <path d="M3 5v14a2 2 0 002 2h16v-5"></path>
                        <path d="M18 12a2 2 0 000 4h4v-4h-4z"></path>
                    </svg>
                </div>
                <div class="relative z-10">
                    <p class="text-[10px] lg:text-xs font-semibold tracking-widest text-gray-300 uppercase mb-2">TOTAL SALDO DITERIMA</p>
                    <h3 class="text-2xl lg:text-4xl font-bold mb-3 lg:mb-6 tracking-tight">Rp. {{ number_format($totalPemasukanBulanIni, 0, ',', '.') }}</h3>
                    <div class="flex items-center gap-2 text-xs lg:text-sm text-gray-300">
                        <i class="ph ph-clock-counter-clockwise opacity-60"></i>
                        <p>Akumulasi Transaksi Bulan Ini</p>
                    </div>
                </div>
            </div>

            <!-- Card Kanan: Saldo Terkirim -->
            <div class="bg-secondary-gradient rounded-2xl p-6 lg:p-7 relative overflow-hidden shadow-sm border border-white">
                <div class="absolute right-6 top-1/2 -translate-y-1/2 w-32 h-32 opacity-[0.04] text-primary">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" class="w-full h-full">
                        <path d="M21 12V7H5a2 2 0 010-4h14v4"></path>
                        <path d="M3 5v14a2 2 0 002 2h16v-5"></path>
                        <path d="M18 12a2 2 0 000 4h4v-4h-4z"></path>
                    </svg>
                </div>
                <div class="relative z-10">
                    <p class="text-[10px] lg:text-xs font-semibold tracking-widest text-textGray uppercase mb-2">TOTAL SALDO TERKIRIM</p>
                    <h3 class="text-2xl lg:text-4xl font-bold mb-3 lg:mb-6 tracking-tight text-primary">Rp. {{ number_format($totalPengeluaranBulanIni, 0, ',', '.') }}</h3>
                    <div class="flex items-center gap-2 text-xs lg:text-sm text-textGray">
                        <i class="ph ph-clock-counter-clockwise opacity-40"></i>
                        <p>Akumulasi Transaksi Bulan Ini</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- BOTTOM SECTION: Form & Riwayat -->
        <div class="mt-10 flex flex-col lg:flex-row gap-10">
            <!-- FORMULIR TRANSFER (Kiri) -->
            <div class="lg:w-7/12 bg-white rounded-3xl p-6 lg:p-8 shadow-[0_4px_24px_rgba(0,0,0,0.02)] border border-gray-50 h-fit">
                <div class="flex items-center gap-4 mb-8">
                    <div class="w-1.5 h-7 bg-accentYellow rounded-full"></div>
                    <h3 class="text-lg lg:text-2xl font-bold text-textDark">Formulir Transfer</h3>
                </div>
                <form id="form-transfer-nasabah" action="{{ route('transfer.proses') }}" method="POST" class="space-y-6">
                    @csrf
                    <div id="alertContainer" class="space-y-3 mb-4">
                        @if (session('error'))
                            <div class="flex items-center gap-3 p-4 text-xs lg:text-sm text-red-700 border border-red-200 rounded-xl bg-red-50 animate-fade-in" role="alert">
                                <svg class="w-5 h-5 text-red-500 shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                <div class="font-semibold">
                                    {{ session('error') }}
                                </div>
                            </div>
                        @endif

                        @if ($errors->any())
                            <div class="flex gap-3 p-4 text-xs lg:text-sm text-red-700 border border-red-200 rounded-xl bg-red-50 animate-fade-in" role="alert">
                                <svg class="w-5 h-5 text-red-500 shrink-0 mt-0.5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                <div>
                                    <span class="font-bold block mb-1">Periksa kembali inputan Anda:</span>
                                    <ul class="list-disc list-inside space-y-1 pl-1 opacity-90 font-medium">
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                        @endif

                        @if (session('success'))
                            <div class="flex items-center gap-3 p-4 text-xs lg:text-sm text-emerald-700 border border-emerald-200 rounded-xl bg-emerald-50 animate-fade-in" role="alert">
                                <svg class="w-5 h-5 text-emerald-500 shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                <div class="font-semibold">
                                    {{ session('success') }}
                                </div>
                            </div>
                        @endif
                    </div>

                    <div>
                        <label class="block text-xs font-semibold text-textGray mb-2">No Rekening Penerima</label>
                        <input type="text" inputmode="numeric" name="id_penerima" id="id_penerima" value="{{ old('id_penerima') }}" required oninput="this.value = this.value.replace(/[^0-9]/g, '')" class="w-full border border-formBorder rounded-xl p-3 text-textDark outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors" placeholder="">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-textGray mb-2">Nama Penerima</label>
                        <input type="text" name="nama_penerima" id="nama_penerima" value="{{ old('nama_penerima') }}" readonly required class="w-full border border-formBorder rounded-xl p-3 text-textDark outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors" placeholder="">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-textGray mb-2">Nominal Transfer (Rp)</label>
                        <input type="text" inputmode="numeric" name="jumlah_transfer" id="jumlah_transfer" value="{{ old('jumlah_transfer') }}" required min="1000" class="w-full border border-formBorder rounded-xl p-3 text-textDark outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors" placeholder="0">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-textGray mb-2">Nominal Admin (Rp)</label>
                        <input type="text" name="nominal_admin" id="nominal_admin" value="Rp {{ number_format($biaya_admin->nominal, 0, ',', '.') }}" readonly required min="1000" class="w-full border border-formBorder rounded-xl p-3 text-textDark outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors" placeholder="">
                        <input type="hidden" name="transaksi_id" value="{{ $biaya_admin->id }}">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-textGray mb-2">Catatan (Opsional)</label>
                        <textarea rows="4" name="catatan" id="catatan" class="w-full border border-formBorder rounded-xl p-3 text-textDark outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors resize-none" placeholder="">{{ old('catatan') }}</textarea>
                    </div>
                    <button type="submit" id="btnSubmit" class="w-full bg-success-gradient hover:bg-green-700 text-white font-bold text-sm py-4 rounded-xl transition-colors mt-2 shadow-sm">Kirim</button>
                </form>
            </div>

            <!-- RIWAYAT TERBARU (Kanan) -->
            <div class="lg:w-5/12">
                <div class="flex justify-between items-center mb-8 px-2">
                    <h3 class="text-[16px] font-bold text-gray-800">Riwayat Transfer</h3>
                    <button onclick="switchView('history')" class="text-[11px] font-bold text-gray-800 hover:text-primary transition-colors">Lihat Semua</button>
                </div>

                <div class="space-y-4 px-2">
                    @if($riwayatTerbaru->isEmpty())
                        <div class="text-center py-6 text-gray-500 text-[13px]">
                            <p>Belum ada riwayat transaksi.</p>
                        </div>
                    @endif
                        @foreach( $riwayatTerbaru as $item)
                        <div class="flex justify-between items-center">
                            <div class="flex items-center gap-2">
                                <i class="ph-fill ph-user-circle text-[32px] lg:text-[44px] text-[#1c3a5a]"></i>
                                <div>
                                     <p class="font-bold text-[13px] lg:text-[14px] text-gray-800">
                                        @if ($item->id_pengirim == auth()->user()->nasabah->rekening->id)
                                            {{ $item->nama_penerima }}
                                        @else
                                            {{ $item->pengirim->nasabah->user->name ?? 'Nasabah' }}
                                        @endif
                                    </p>
                                    <p class="text-[9px] lg:text-[10px] text-gray-500 mt-0.5">{{ $item->created_at->format('d-m-Y H:i') }}</p>
                                </div>
                            </div>
                            @if ($item->id_pengirim == auth()->user()->nasabah->rekening->id)
                                <p class="font-bold text-[12px] lg:text-[13px] text-red-500">
                                    - Rp. {{ number_format($item->jumlah_transfer, 0, ',', '.') }}
                                </p>
                            @else
                                <p class="font-bold text-[12px] lg:text-[13px] text-green-500">
                                    + Rp. {{ number_format($item->jumlah_transfer, 0, ',', '.') }}
                                </p>
                            @endif
                        </div>
                        @endforeach
                </div>
            </div>
        </div>
    </div>
    </div>

    <!-- VIEW HISTORY: Riwayat Transaksi -->
    <div id="viewHistory" class="fade-in {{ request()->has('page') ? 'block' : 'hidden' }}">
        <div class="bg-white rounded-2xl sm:rounded-[32px] shadow-[0_4px_24px_rgba(0,0,0,0.02)] border border-gray-50 p-4 sm:p-6 lg:p-12 mt-4 lg:mt-0">
            <div class="flex justify-between items-center mb-6 lg:mb-10">
                <button onclick="switchView('main')" class="text-xs lg:text-[14px] font-bold text-textDark hover:text-primary transition-colors flex items-center gap-1">
                    <i class="ph ph-arrow-left"></i> Kembali
                </button>
                <h3 class="text-base lg:text-[22px] font-bold text-textDark">Riwayat Transfer</h3>
            </div>

            <div class="space-y-3 sm:space-y-4">
                @if($riwayatTransfer->isEmpty())
                    <div class="text-center py-8 text-gray-500 text-xs sm:text-[13px]">
                        <p>Belum ada riwayat transaksi.</p>
                    </div>
                @endif
                @foreach($riwayatTransfer as $item)
                    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 p-3.5 sm:p-4 rounded-2xl border border-gray-100 hover:border-gray-200 transition-all bg-white">
                        <div class="flex items-start sm:items-center gap-3 min-w-0 flex-1">
                            <i class="ph-fill ph-user-circle text-3xl sm:text-4xl text-[#1c3a5a] shrink-0"></i>
                            <div class="min-w-0 flex-1">
                                <p class="font-bold text-xs sm:text-sm text-gray-800 truncate">
                                    @if ($item->id_pengirim == auth()->user()->nasabah->rekening->id)
                                        Transfer ke {{ $item->nama_penerima }}
                                    @else
                                        Transfer dari {{ $item->pengirim->nasabah->user->name ?? 'Nasabah' }}
                                    @endif
                                </p>
                                <p class="text-[10px] sm:text-xs text-gray-500 mt-0.5">{{ $item->created_at->format('d-m-Y H:i') }}</p>
                                @if(!empty($item->catatan))
                                    <p class="text-[10px] sm:text-xs text-gray-400 mt-0.5 break-words line-clamp-2">Catatan: {{ $item->catatan }}</p>
                                @endif
                            </div>
                        </div>
                        <div class="self-end sm:self-center shrink-0">
                            @if ($item->id_pengirim == auth()->user()->nasabah->rekening->id)
                                <p class="font-bold text-xs sm:text-sm text-red-500">
                                    - Rp. {{ number_format($item->jumlah_transfer, 0, ',', '.') }}
                                </p>
                            @else
                                <p class="font-bold text-xs sm:text-sm text-green-500">
                                    + Rp. {{ number_format($item->jumlah_transfer, 0, ',', '.') }}
                                </p>
                            @endif
                        </div>
                    </div>
                @endforeach
            </div>
            <!-- Pagination -->
            <x-pagination :paginator="$riwayatTransfer" />
        </div>
    </div>


</div>
@endsection

@section('scripts')
<script>
    function switchView(viewName) {
        const mainView = document.getElementById('viewMain');
        const historyView = document.getElementById('viewHistory');
        
        if (viewName === 'history') {
            mainView.classList.remove('block');
            mainView.classList.add('hidden');
            historyView.classList.remove('hidden');
            historyView.classList.add('block');
        } else {
            historyView.classList.remove('block');
            historyView.classList.add('hidden');
            mainView.classList.remove('hidden');
            mainView.classList.add('block');
        }
        
        // Scroll top
        document.querySelector('main').scrollTo({ top: 0, behavior: 'smooth' });
    }

    const inputTransfer = document.getElementById('jumlah_transfer');

    // Fungsi untuk memformat angka menjadi format ribuan dengan titik
    function formatRupiah(angka) {
        // Hapus semua karakter selain angka
        let numberString = angka.replace(/[^,\d]/g, '').toString();
        let split = numberString.split(',');
        let sisa = split[0].length % 3;
        let rupiah = split[0].substr(0, sisa);
        let ribuan = split[0].substr(sisa).match(/\d{3}/gi);

        if (ribuan) {
            let separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }

        return split[1] !== undefined ? rupiah + ',' + split[1] : rupiah;
    }

    // Event saat pengguna mengetik (input & keyup agar menolak non-digit secara penuh)
    inputTransfer.addEventListener('input', function(e) {
        this.value = formatRupiah(this.value.replace(/[^0-9]/g, ''));
    });

    // Jalankan fungsi saat halaman pertama kali dimuat (jika ada nilai old dari backend)
    window.addEventListener('DOMContentLoaded', function() {
        if (inputTransfer.value) {
            inputTransfer.value = formatRupiah(inputTransfer.value.replace(/[^0-9]/g, ''));
        }
    });

       // Buat variabel timer di luar agar bisa di-reset setiap kali mengetik
    let delayTimer;

    const rekeningLogin = "{{ auth()->user()->nasabah->rekening->id ?? '' }}";
    const btnSubmit = document.getElementById('btnSubmit');

    document.getElementById('id_penerima').addEventListener('input', function() {
        let noRekening = this.value;
        let inputNoRekening = this;
        let inputNama = document.getElementById('nama_penerima');

        // 1. KELOLA INPUT KOSONG
        if (noRekening.trim() === '') {
            clearTimeout(delayTimer); // batalkan pencarian jika dihapus semua
            inputNama.value = '';
            inputNoRekening.style.borderColor = '#e5e7eb';
            inputNama.style.borderColor = '#e5e7eb';
            return;
        }

            // 2. VALIDASI: JIKA REKENING PENERIMA SAMAN DENGAN REKENING LOGIN
        if (noRekening === rekeningLogin) {
            clearTimeout(delayTimer); // Hentikan timer pencarian API
            inputNama.value = 'Tidak bisa transfer ke rekening sendiri!';
            inputNoRekening.style.borderColor = '#ef4444'; // Border merah halus
            inputNama.style.borderColor = '#ef4444';
            btnSubmit.disabled = true;
            return; // Hentikan eksekusi, jangan jalankan fetch API
        }

        // Tampilkan status "Mencari..." agar user tahu sistem sedang bekerja
        inputNama.value = 'Mencari data...';

        // 2. TEKNIK DEBOUNCE: Hapus timer yang lama jika user masih mengetik
        clearTimeout(delayTimer);

        // Set timer baru: Tunggu 500ms (0.5 detik) setelah ketikan terakhir berhenti
        delayTimer = setTimeout(function() {
            
            // Panggil Route API Laravel setelah user BERHENTI mengetik
            fetch(window.location.origin + '/cek-rekening/' + noRekening)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // REKENING ADA
                        inputNama.value = data.nama;
                        inputNoRekening.style.borderColor = '#10b981'; // Hijau halus
                        inputNama.style.borderColor = '#10b981';
                        btnSubmit.disabled = false;
                    } else {
                        // REKENING TIDAK ADA
                        inputNama.value = 'Rekening Tidak Ditemukan!';
                        inputNoRekening.style.borderColor = '#ef4444'; // Merah halus
                        inputNama.style.borderColor = '#ef4444';
                        btnSubmit.disabled = true;
                    }
                })
                .catch(error => {
                    console.error('Error fetch:', error);
                    inputNama.value = 'Gagal memuat data internet';
                });

        }, 500); // <-- 500 milidetik (0.5 detik). Silakan dipercepat ke 300 jika dirasa kurang kilat
    });

    // CLIENT SIDE FORM SUBMIT VALIDATOR
    document.getElementById('form-transfer-nasabah').addEventListener('submit', function(e) {
        let errors = [];
        const alertContainer = document.getElementById('alertContainer');
        const idPenerima = document.getElementById('id_penerima').value.trim();
        const namaPenerima = document.getElementById('nama_penerima').value.trim();
        const jumlahTransfer = document.getElementById('jumlah_transfer').value.trim();

        if (!idPenerima) {
            errors.push('Nomor Rekening Penerima wajib diisi.');
        } else if (namaPenerima === 'Rekening Tidak Ditemukan!' || namaPenerima === 'Mencari data...' || namaPenerima === 'Tidak bisa transfer ke rekening sendiri!' || !namaPenerima) {
            errors.push('Rekening Penerima tidak valid atau tidak ditemukan.');
        }
        if (!jumlahTransfer || jumlahTransfer === '0') {
            errors.push('Nominal Transfer wajib diisi.');
        }

        if (errors.length > 0) {
            e.preventDefault(); // Mencegah form dikirim

            // Buat HTML alert merah simple
            let errorHTML = `
                <div class="flex gap-3 p-4 text-xs lg:text-sm text-red-700 border border-red-200 rounded-xl bg-red-50 animate-fade-in" role="alert">
                    <svg class="w-5 h-5 text-red-500 shrink-0 mt-0.5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    <div>
                        <span class="font-bold block mb-1">Periksa kembali inputan Anda:</span>
                        <ul class="list-disc list-inside space-y-1 pl-1 opacity-90 font-medium">
            `;
            errors.forEach(function(err) {
                errorHTML += `<li>${err}</li>`;
            });
            errorHTML += `
                        </ul>
                    </div>
                </div>
            `;
            alertContainer.innerHTML = errorHTML;
            alertContainer.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    });

    // Auto-scroll to alert container on load if backend redirects with error/success
    @if(session('success') || session('error') || $errors->any())
        document.addEventListener('DOMContentLoaded', function() {
            const container = document.getElementById('alertContainer');
            if (container) {
                container.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        });
    @endif
</script>
@endsection
